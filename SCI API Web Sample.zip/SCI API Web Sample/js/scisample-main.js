/*global RDMSciV1 Base64Binary Tiff*/

/** 
 * A sample helper class that wraps SCI operations into JQuery Deferred objects.
 * 
 * This class depends on jquery 1.8.0+ 
 * 
 **/
function SciJqueryHelper(scannerAddress) {
    var mSciConnection, self=this;

    this.timer = function ( timeout ) {
        //Create a new Deferred object - this will be
        // resolved when the timer is finished.
        var deferred = $.Deferred();
        //Lock the deferred object. We are doing this so we can alter the resultant object.
        var promise = deferred.promise();
        // Define our internal timer - this is what will be powering the delay.
        var internalTimer = null;
        // Store the context in which this timer was executed.
        // This way, we can resolve the timer in the same
        // context.
        var resolveContext = this;
        // Get any additional resolution arguments that may
        // have been passed into the timer.
        var resolveArguments = Array.prototype.slice.call(arguments, 1);
        
        // Add a clear() method to the timer. This will stop
        // the underlying timer and reject the deferred.
        promise.clear = function(){
            if( internalTimer !== null ) {
                // Clear the timer.
                clearTimeout( internalTimer );
                // Reject the deferred. When rejecting, let's use
                // the given context and arguments.
                deferred.rejectWith(resolveContext, resolveArguments);
                internalTimer = null;
            }
        };
        
        // Set the internal timer.
        internalTimer = setTimeout( function(){
            // Once the timer has executed, we'll resolve
            // the deferred object. When doing so, let's
            // use the given context and arguments.
            deferred.resolveWith(resolveContext, resolveArguments);
            // Clear the timer (probably not necessary).
            clearTimeout( internalTimer );
        }, timeout);

        return( promise );
    };

    function asJqueryDeferred(sciDeferred) {
        if(sciDeferred===null || sciDeferred===undefined) {
            return $.Deferred( function(){
                this.resolve();
            });
        } else {
            return $.Deferred( function() {
                var that = this;
                sciDeferred.onComplete(function(){
                    var argArray = Array.prototype.slice.call(arguments);
                    argArray.shift();
                    that.resolve.apply(null, argArray);
                });
                sciDeferred.onError(function(){
                    var argArray = Array.prototype.slice.call(arguments);
                    argArray.shift();
                    that.reject.apply(null, argArray);
                });
            });
        }
    }
    
    function getXmlElemValue($xml, elemName, defValue) {
        var $elem = $xml.find(elemName);
        if( $elem.length === 0 ) {
            return defValue;
        }
        return $elem.text();
    }

    function parseSciExceptions($xml) {
        var exceps = { errors: [], warnings: [], timeout:false};
        var $exception = $xml.find('Exception');
        if ( $exception !== undefined && $exception.length !== 0 ) {
            $exception.children().each(function() {
                var excep;
                var $level = $(this).find("Level");
                if( $level.length !== 0 ) {
                    if( $level.text() == "[Error]" ) {
                        exceps.errors.push({
                            level: "[Error]",
                            code: $(this).find("Code").text(),
                            desc: $(this).find("Description").text(),
                            action: $(this).find("Action").text()
                        });
                    } else if( $level.text() == "[Warning]" ) {
                        excep = {
                                level: "[Warning]",
                                code: $(this).find("Code").text(),
                                desc: $(this).find("Description").text(),
                                action: $(this).find("Action").text()
                            };
                        exceps.warnings.push(excep);
                        if( excep.code === "[Timeout]") {
                            exceps.timeout = true;
                        }
                    }
                }
            });
        }
        return exceps;
    }
    
    function parseSciNotifcations($xml) {
        var $notifcations = $xml.find('Notifications'), notifications = {rawText: ''};
        if( $notifcations.length > 0 ) {
            notifications.rawText = $notifcations.text().trim();
            if( notifications.rawText.indexOf('[Accepted]') !== -1 ) {
                notifications.accepted = true;
            }
            if( notifications.rawText.indexOf('[ErrorAck]') !== -1 ) {
                notifications.ackError = true;
            }
            if( notifications.rawText.indexOf('[DoubleFeed]') !== -1 ) {
                notifications.doubleFeed = true;
            }
            if( notifications.rawText.indexOf('[JpegTooSmall]') !== -1 ) {
                notifications.jpegTooSmall = true;
            }
            if( notifications.rawText.indexOf('[JpegTooBig]') !== -1 ) {
                notifications.jpegTooBig = true;
            }
            if( notifications.rawText.indexOf('[Hold]') !== -1 ) {
                notifications.hold = true;
            }
            if( notifications.rawText.indexOf('[HopperEmpty]') !== -1 ) {
                notifications.hopperEmpty = true;
            }
            if( notifications.rawText.indexOf('[ImageMissing]') !== -1 ) {
                notifications.imageMissing = true;
            }
            if( notifications.rawText.indexOf('[ImageTooDark]') !== -1 ) {
                notifications.imageTooDark = true;
            }
            if( notifications.rawText.indexOf('[ImageTooLight]') !== -1 ) {
                notifications.imageTooLight = true;
            }
            if( notifications.rawText.indexOf('[LastItem]') !== -1 ) {
                notifications.lastItem = true;
            }
            if( notifications.rawText.indexOf('[MicrMissing]') !== -1 ) {
                notifications.micrMissing = true;
            }
            if( notifications.rawText.indexOf('[MicrRejects]') !== -1 ) {
                notifications.MicrRejects = true;
            }
            if( notifications.rawText.indexOf('[OcrMissing]') !== -1 ) {
                notifications.ocrMissing = true;
            }
            if( notifications.rawText.indexOf('[OcrRejects]') !== -1 ) {
                notifications.ocrRejects = true;
            }
            if( notifications.rawText.indexOf('[Printing]') !== -1 ) {
                notifications.printing = true;
            }
            if( notifications.rawText.indexOf('[PrintComplete]') !== -1 ) {
                notifications.printComplete = true;
            }
            if( notifications.rawText.indexOf('[Rejected]') !== -1 ) {
                notifications.rejected = true;
            }
            if( notifications.rawText.indexOf('[SignalButton]') !== -1 ) {
                notifications.signalButton = true;
            }
            if( notifications.rawText.indexOf('[Stopped]') !== -1 ) {
                notifications.stopped = true;
            }
        }
        return notifications;
    }
    
    this.parseSciOutput = function (respXML) {
        var $xml, output = {}, $elem, $child;

        output.xml = respXML;
        
        $xml = $($.parseXML(respXML));
        
        $elem = $xml.find('TimeStamp');
        if ( $elem.length > 0 ) {
            output.timestamp = $elem.text();
        }

        $elem = $xml.find('Irn');
        if ( $elem.length > 0 ) {
            output.irn = $elem.text();
        }

        $elem = $xml.find('Count');
        if ( $elem.length > 0 ) {
            output.count = $elem.text();
        }
        
        output.exceptions = parseSciExceptions($xml);

        output.notifications = parseSciNotifcations($xml);
        
        output.startType = $xml.find('StartType').text();
        if( output.startType === 'ScanSingleItem' || output.startType === 'ScanDecisionItem' || output.startType === 'ScanBatchItems' || output.startType === 'ScanIdCard') {
            $elem = $xml.find('MicrLine');
            if ( $elem.length > 0 ) {
                output.micrLine = $elem.text();
            }
            
            $elem = $xml.find('ParsedMicr');
            if ( $elem.length > 0 ) {
                output.$parsedMicr = $elem;
            }
            
            $elem = $xml.find('ImageFront');
            if ( $elem.length > 0 ) {
                output.$imageFront = $elem;
                $child = $elem.find('Base64Data');
                output.imageFrontBase64 = $child.text();
            }
            
            $elem = $xml.find('ImageBack');
            if ( $elem.length > 0 ) {
                output.$imageBack = $elem;
                $child = $elem.find('Base64Data');
                output.imageBackBase64 = $child.text();
            }
            
            $elem = $xml.find('Ocr');
            if ( $elem.length > 0 ) {
                output.$ocr = $elem;
            }
            
        } else if( output.startType === 'SwipeMsrCard' ) {
            $elem = $xml.find('SwipeTime');
            if ( $elem.length > 0 ) {
                output.swipeTime = $elem.text();
            }
            
            $elem = $xml.find('Decode');
            if ( $elem.length > 0 ) {
                output.decode = $elem.text();
            }
            
            $elem = $xml.find('Track1');
            if ( $elem.length > 0 ) {
                $child = $elem.find('Data');
                output.track1 = $child.text();
                output.$track1 = $elem;
            }
            $elem = $xml.find('Track2');
            if ( $elem.length > 0 ) {
                $child = $elem.find('Data');
                output.track2 = $child.text();
                output.$track2 = $elem;
            }
            $elem = $xml.find('Track3');
            if ( $elem.length > 0 ) {
                $child = $elem.find('Data');
                output.track3 = $child.text();
                output.$track3 = $elem;
            }
        }
        
        return output;
    };

    function parseScannerXMLCaps ($deviceXML) {
        var caps = {};
        
        function parseCapEntry(entryName) {
            var $cap = $deviceXML.find(entryName), capEntry = {available:false, detail: null}
                , $available, $detail;
            if( $cap.length > 0 ) {
                $available = $cap.find('Available');
                if( $available.length > 0 ) {
                    if( $available.text() === 'true' ) {
                        capEntry.available = true;
                    }
                }
                
                if( capEntry.available ) {
                    $detail = $cap.find('Detail');
                    if( $detail.length > 0 ) {
                        capEntry.detail = $detail.text();
                    }
                }
            }
            return capEntry;
        }
        
        caps.feeder = parseCapEntry('CapFeeder');
        caps.idCardImaging = parseCapEntry('CapIdCardImaging');
        caps.msr = parseCapEntry('CapMsr');
        caps.printer = parseCapEntry('CapPrinter');
        caps.signalButton = parseCapEntry('CapSignalButton');

        caps.endorser = parseCapEntry('CapEndorser');
        caps.frank = parseCapEntry('CapFranker');

        return caps;
    }
    
    function parseScannerXMLLicenses($deviceXML) {
        var lic = {OcrANumeric: false, OcrAAlphanumeric: false, OcrBAlphaNumberic: false, BatchFeedRate: null};
        var $elemCap = $deviceXML.find('MetaLicenses');
        lic.text = '';
        if( $elemCap.length > 0 ) {
            lic.rawText = $elemCap.text();
            
            if( lic.rawText.indexOf('OcrANumeric') ) {
                lic.OcrANumeric = true;
            }
            if( lic.rawText.indexOf('OcrAAlphaNumeric') ) {
                lic.OcrAAlphaNumeric = true;
            }
            if( lic.rawText.indexOf('OcrBAlphaNumeric') ) {
                lic.OcrBAlphaNumberic = true;
            }
            if( lic.rawText.indexOf('BatchFeedRate30') ) {
                lic.BatchFeedRate = 30;
            }
            if( lic.rawText.indexOf('BatchFeedRate60') ) {
                lic.BatchFeedRate = 60;
            }
            if( lic.rawText.indexOf('BatchFeedRate90') ) {
                lic.BatchFeedRate = 60;
            }
        }
        return lic; 
    }
    
    function parseScannerXMLVersions($deviceXML) {
        var meta = {};
        meta.scannerType = getXmlElemValue($deviceXML, 'MetaScannerType', '');
        meta.serialNumber = getXmlElemValue($deviceXML, 'MetaSerialNumber', 'N/A');
        return meta;
    }
    
    this.parseScannerXML = function (deviceXML) {
        var $deviceXML = $($.parseXML(deviceXML)), info = {};
        info.caps = parseScannerXMLCaps($deviceXML);
        info.licenses = parseScannerXMLLicenses($deviceXML);
        info.meta = parseScannerXMLVersions($deviceXML);
        return info;
    };
    
    this.tryConnect = function() {
        return asJqueryDeferred(RDMSciV1.connectToDevice(scannerAddress))
            .then(function(sciConn){
                mSciConnection = sciConn;
            }).promise();
    };
    
    this.claimAndGetScannerInfo = function (userId, scannerType) {
        return asJqueryDeferred(mSciConnection.claimScanner(userId, scannerType))
            .then( function() {
                return asJqueryDeferred(mSciConnection.getScannerXml());
            }).then( function(scannerXml) {
                var deferred = $.Deferred(function(){
                    this.resolve(self.parseScannerXML(scannerXml));
                });
                return deferred;
            }).promise();
    };
    
    this.resetScannerIfError = function(options) {
        var deferred = $.Deferred();
        var retryCount = 0;
        
        if( options === undefined ) {
            options = {};
        }

        function onResetDeviceError(sciConn, errorMsg) {
            deferred.reject(errorMsg);
        }
        
        function onErrorAckResponse(sciConn, respXML) {
            var $xml, notifications;
            if( !respXML ) {
                deferred.reject('Failed reseting the device (ERRORACK response is empty).');
                return;
            }
            $xml = $($.parseXML(respXML));
            notifications = parseSciNotifcations($xml);
            if( notifications.AckError ) {
                deferred.resolve();
            } else if ( retryCount < 50 ) {
                ++retryCount;
                mSciConnection.getResponseXml(1).onComplete( onErrorAckResponse ).onError( onResetDeviceError );
            } else {
                deferred.reject('Failed reading ERRORACK response (exceeds retry limitation).');
            }
        }

        mSciConnection.getState().onComplete( function(conn, state) {
            if( state.toUpperCase() === 'ERROR' ) {
                if( typeof options.beforeReset === 'function' ) {
                    options.beforeReset(state);
                }
                mSciConnection.completeOperation(5).onComplete(function(){
                    mSciConnection.getResponseXml(1).onComplete( onErrorAckResponse ).onError( onResetDeviceError );
                }).onError(onResetDeviceError);   
                return;
            } else if (options.abortBusy && state.toUpperCase() === 'BUSY') {
                if( typeof options.beforeReset === 'function' ) {
                    options.beforeReset(state);
                }
                mSciConnection.completeOperation(4).onComplete(function(){
                    deferred.resolve();
                }).onError(onResetDeviceError);
            } else {
                deferred.resolve();
            }
        }).onError( onResetDeviceError );
        
        return deferred.promise();
    };

    function drainSciResponses() {
        var deferred = $.Deferred();
        deferred.sciRetryCount = 0;
        
        function onDrainResponseComplete(sciConn, resp){
            if( resp.length === 0 ) {
                deferred.resolve();
                return;
            }
            if( ++deferred.sciRetryCount > 500 ) {
                deferred.reject("Failed draining SCI responses. (Too many responses in the queue)");
                return;
            }
            deferred.sciOperation = mSciConnection.getResponseXml()
                .onComplete(onDrainResponseComplete)
                .onError( onDrainResponsesError);
        }

        function onDrainResponsesError(sciConn, msg){
            deferred.reject(msg);
        }

        deferred.sciOperation = mSciConnection.getResponseXml().onComplete(onDrainResponseComplete).onError(onDrainResponsesError);
        return deferred;
    }

    this.startOperationAndGetResponse = function(startType, startOperationXML) {
        return drainSciResponses().then( function() {
                return asJqueryDeferred(mSciConnection.startOperation(startType, startOperationXML));
            }).then(function(){
                return asJqueryDeferred(mSciConnection.getResponseXml(1));
            }).then(function(respXML){
                var deferred = $.Deferred(function(){
                    this.resolve(self.parseSciOutput(respXML));
                });
                return deferred;
            }).promise();
    };

    this.completeOperation = function(completeType, completeXML) {
        return asJqueryDeferred(mSciConnection.completeOperation(completeType, completeXML)).promise();
    };
    
    this.getNextResponse = function() {
        return asJqueryDeferred(mSciConnection.getResponseXml(1)).then(function(respXML){
            var deferred = $.Deferred(function(){
                this.resolve(self.parseSciOutput(respXML));
            });
            return deferred;
        }).promise();
    };

    this.release = function(userId) {
        if(mSciConnection) {
            return asJqueryDeferred(mSciConnection.releaseScanner(userId)).promise();
        } else {
            var deferred = $.Deferred(function(){
                this.resolve();
            });
            return deferred;
        }
    };
}

//User Interfaces

$(function() {
    
    var USER_ID = 'SCI.SAMPLE', mSciHelper = null, mCurrentOperationXML = null, mHasResponseUploadError, mResponses = [], mHasPreviousResponseError, mIsBmp = false;
    
    function base64ToArrayBuffer(base64) {
        var binary_string =  window.atob(base64);
        var len = binary_string.length;
        var bytes = new Uint8Array( len );
        for (var i = 0; i < len; i++)        {
            bytes[i] = binary_string.charCodeAt(i);
        }
        return bytes.buffer;
    }

    //SCI operations

    function sampleConnectAndClaim(scannerType, scannerAddr) {
        if ( mSciHelper ) {
            mSciHelper.release(USER_ID);
        }
        mSciHelper = new SciJqueryHelper(scannerAddr);
        
        $("body").css("cursor", "progress");
        mSciHelper.tryConnect().then(function(){
            return mSciHelper.claimAndGetScannerInfo(USER_ID, scannerType);
        }).done(function(deviceInfo){
            $("body").css("cursor", "default");

            $('#btnSciActionClaimDevice').prop('disabled', 'disabled');
            $('#btnSciActionStartOperation').removeProp('disabled');
            $('#btnClearError').removeProp('disabled');
            $('#btnSciActionReleaseDevice').removeProp('disabled');
            
            $('.opSciOperationTypes').prop('disabled', 'disabled');
            $('.opSciIdleActions').removeProp('disabled');
            $('.opRuningParameters').removeProp('disabled');
            
            $('.opTestTarget').prop('disabled', 'disabled');
            

            $('#spanScannerInfoType').html(deviceInfo.meta.scannerType);
            $('#spanScannerInfoSN').html(deviceInfo.meta.serialNumber);
            $('#spanScannerInfoLicense').html(deviceInfo.licenses.rawText);

            if( deviceInfo.caps.feeder.available && deviceInfo.caps.feeder.detail.toUpperCase() != 'SINGLE' && deviceInfo.licenses.BatchFeedRate !== null ) {
                $('#radioOpTypeBatch').removeProp('disabled');
                $('#radioOpTypeBatch').addClass('opSciIdleActions');
            }
            
            if( deviceInfo.caps.idCardImaging.available ) {
                $('#radioOpTypeIDCard').removeProp('disabled');
                $('#radioOpTypeIDCard').addClass('opSciIdleActions');
            }
            
            if( deviceInfo.caps.msr.available ) {
                $('#radioOpTypeMSR').removeProp('disabled');
                $('#radioOpTypeMSR').addClass('opSciIdleActions');
            }
            
            if( deviceInfo.caps.printer.available ) {
                $('#radioOpTypePrint').removeProp('disabled');
                $('#radioOpTypePrint').addClass('opSciIdleActions');
            }

            if( deviceInfo.caps.endorser.available ) {
                $('#labelOpOptionsEndorse').show();
            } else {
                $('#labelOpOptionsEndorse').hide();
            }

            if( deviceInfo.caps.frank.available ) {
                $('#labelOpOptionsFrank').show();
            } else {
                $('#labelOpOptionsFrank').hide();
            }

            $('#divSciScannerInfo').show();
            
            clearResultsAndDisplay();
            $('#divOperationResultSection').show();

        }).fail( function(errorMsg) {
            $("body").css("cursor", "default");
            alert(errorMsg);
            resetUI();
        });
    }
    
    function sampleReleaseDevice() {
        if ( mSciHelper !== null ) {
            mSciHelper.release(USER_ID).done( function() {
                resetUI();
            }).fail( function(errorMsg) {
                alert(errorMsg);
                resetUI();
            });
        }
    }
    
    function getImageFormat(startOperationXml) {
        var isBmp = false;
        var $xml = $($.parseXML(startOperationXml));

        var $image = $xml.find('Image');
        if ( $image == undefined || $image.length == 0) {
            return;
        }

        var $format = $image.find('Format');
        if ( $format.length > 0 ) {
            isBmp = ($format.text() == 'Bmp');
        }
        return isBmp;
    }

    function sampleStartOpertion(startType, startOperationXml) {
        mHasResponseUploadError = false;
        mHasPreviousResponseError = false;
        mCurrentOperationXML = startOperationXml;
        mIsBmp = getImageFormat(startOperationXml);

        mSciHelper.resetScannerIfError({
            abortBusy: true,
            beforeReset: function(state) {
                alert('Scanner is in [' + state + '] state. Click OK to continue the operation');
            }
        }).then( function(){
            return mSciHelper.startOperationAndGetResponse(startType, startOperationXml);
        }).done( sampleOnOperationResponse ).fail( sampleOnOperationError );
    }

    function sampleStopOperation() {
        mSciHelper.completeOperation(3).done(function(){
            sampleOnOperationFinished();
        }).fail(sampleOnOperationError);
    }  

    function sampleOnOperationResponse(responseObject) {
        var completeDeferred;

        function sampleWaitForPrintComplete() {            
            mSciHelper.completeOperation(6).then( function(){
                return mSciHelper.getNextResponse();
            }).done( function (prtResponseObj) {            
                if( prtResponseObj.startType !== 'Print' ) {
                    sampleOnOperationError('PrintComplete failed(Invalid SCI response type).');
                    return;
                }
                if( prtResponseObj.notifications.printComplete ) {
                    sampleOnOperationFinished();
                } else if( prtResponseObj.exceptions.timeout ) {
                    sampleWaitForPrintComplete();
                    return;
                } else {
                    sampleOnOperationError('PrintComplete failed([Timeout] or [PrintComplete] are not set).');
                }
            } ).fail(sampleOnOperationError);
        }
        
        if( $('#checkboxOpSaveResponse').is(':checked') && $('#textOpResponseURL').val().length > 0) {
            if( !mHasResponseUploadError ) {
                $.ajax({
                    url: $('#textOpResponseURL').val(),
                    type: 'post',
                    contentType: 'application/xml',
                    dataType: 'text',
                    data: responseObject.xml
                }).fail( function(){
                    alert('Failed sending SCI response to ' + $('#textOpResponseURL').val());
                    mHasResponseUploadError = true;
                } );
            }
        }
        
        sampleShowResults(responseObject);

        var exceptions = responseObject.exceptions, notifications = responseObject.notifications;       
        
        if( exceptions.timeout ) {
            if( responseObject.startType === 'SwipeMsrCard' ) {
                sampleOnOperationError('Timed out waiting for swiping MSR.');
            } else if( responseObject.startType === 'Print' ) {
                sampleOnOperationError('Printing timed out.');
            } else {
                sampleOnOperationError('Timed out waiting for inserting document.');
            }
            return;
        }
        
        if ( responseObject.startType === 'ScanDecisionItem' ) {
            if( notifications.hold ) {
                window.setTimeout(function () {
                    var xml;
                    if( confirm('Item is in hold position.\nClick OK to accept the document with virtual endorsement; Cancel will just release the item from hold position.') ) {
                        xml = replaceOperationXMLParameter($('#templateCompleteXMLDecision').html().trim());
                        completeDeferred = mSciHelper.completeOperation(1, xml);
                    } else {
                        completeDeferred = mSciHelper.completeOperation(2);
                    }
                    completeDeferred.then(function(){
                        return mSciHelper.getNextResponse();
                    }).done( sampleOnOperationResponse ).fail( sampleOnOperationError );
                }, 50);
            } else if( exceptions.errors.length > 0 ) {
                sampleOnOperationError( '[' + responseObject.startType +'] operation had error(s).', true);
            } else {
                sampleOnOperationFinished();
            }
            return;
        }
        
        if ( responseObject.startType === 'ScanBatchItems' ) {
            if( exceptions.errors.length > 0 ) {
                mHasPreviousResponseError = true;
                alert('[' + responseObject.startType +'] operation had error(s), and the operation will be stopped.');
            }

            if( notifications.hopperEmpty ) {
                if(!mHasPreviousResponseError) {
                    window.setTimeout(function () {
                        if( confirm('Hopper Empty detected!\nFill the hopper and click Ok to scan another batch.') ) {
                            clearResultsAndDisplay();
                            sampleStartOpertion(3, mCurrentOperationXML);
                        } else {
                            sampleOnOperationFinished();
                        }
                    }, 50);
                    return;
                }
            }

            if( notifications.lastItem ) {
                if(mHasPreviousResponseError) {
                    $('#divSciOperationLogs').append('<div>[' + responseObject.startType +'] operation stopped on error(s)!</div>');
                }

                sampleOnOperationFinished();
            } else {
                mSciHelper.getNextResponse().done( sampleOnOperationResponse ).fail(sampleOnOperationError);
            }
            return;
        }

        if( exceptions.errors.length > 0 ) {
            sampleOnOperationError( '[' + responseObject.startType +'] operation had error(s).', true);
            return;
        }

        if( responseObject.startType === 'Print' ) {
            if( notifications.printing ) {
                sampleWaitForPrintComplete();
            }
            return;
        }
        
        sampleOnOperationFinished();
    }

    function sampleOnOperationError(errMsg, promptAlert) {
        alert(errMsg);
        
        mSciHelper.resetScannerIfError({
            beforeReset: function(state) {
                if( promptAlert === true ) {
                    alert('Scanner is in [' + state + '] state. Click OK to recovery from error');
                }
            }
        }).always( function(){
            sampleOnOperationFinished();
        });
    }

    function sampleOnOperationFinished() {
        $('.opSciIdleActions').removeProp('disabled');
        $('.opRuningParameters').removeProp('disabled');
        $('.opSciBusyActions').prop('disabled', 'disabled');
    }

    //Display SCI operation results
    
    function sampleShowResults( respObj ) {
        var exceptions = respObj.exceptions, notifications = respObj.notifications,
            except, i;
        
        if( $('#checkboxOpDisplayRawResponse').is(':checked') ) {
            mResponses.push(respObj);

            $('#txtResponses').val( $('#txtResponses').val() 
                +  '-------------------- #' + mResponses.length.toString() + ' --------------------\n'
                + respObj.xml
                + '\n\n' );
            $('#txtResponses').scrollTop($('#txtResponses').scrollHeight);
        }

        $('#divSciOutputItemDetails').empty();
        if( respObj.timestamp ) {
            $('#divSciOutputItemDetails').append('<div> Timestamp:' + respObj.timestamp + '</div>');
        }
        if( respObj.irn ) {
            $('#divSciOutputItemDetails').append('<div> IRN:' + respObj.irn + '</div>');
        }
        
        if( respObj.micrLine ) {
            $('#divSciOutputItemDetails').append('<div> MICR:' + respObj.micrLine + '</div>');
        }
        
        if( respObj.track1 ) {
            $('#divSciOutputItemDetails').append('<div> Track 1:' + respObj.track1 + '</div>');
        }
        
        if( respObj.track2 ) {
            $('#divSciOutputItemDetails').append('<div> Track 2:' + respObj.track2 + '</div>');
        }
        
        if( respObj.track3 ) {
            $('#divSciOutputItemDetails').append('<div> Track 3:' + respObj.track3 + '</div>');
        }
        
        if( notifications.rawText.length > 0 ) {
            $('#divSciOutputNotificationDetails').html(notifications.rawText);
        } else {
            $('#divSciOutputNotificationDetails').empty();
        }

        $('#divSciOutputExceptionDetails').empty();
        if( exceptions.errors.length > 0 || exceptions.warnings.length > 0 ) {
            $('#divSciOutpuException').show();
            for( i = 0; i < exceptions.errors.length; ++i ) {
                except = exceptions.errors[i];
                $('#divSciOutputExceptionDetails').append('<div>' + except.level  + ':' + except.code + ' ' + except.desc + '</div>');
            }
            for( i = 0; i < exceptions.warnings.length; ++i ) {
                except = exceptions.warnings[i];
                $('#divSciOutputExceptionDetails').append('<div>' + except.level + ':' + except.code + ' ' + except.desc + '</div>');
            }
        } else {
            $('#divSciOutpuException').hide();
        }

        $('#divSciOutputImageFront').empty();
        $('#divSciOutputImageBack').empty();
        if( $('#checkboxOpDisplayImage').is(':checked') && (respObj.imageFrontBase64 || respObj.imageBackBase64) )
        {
            $('#divSciOutputImages').show();
            sampleShowImage($('#divSciOutputImageFront'), respObj.imageFrontBase64);
            sampleShowImage($('#divSciOutputImageBack'), respObj.imageBackBase64);
        } else {
            $('#divSciOutputImages').hide();
        }
    }

    function sampleShowImage($comp, base64Str) {
        if (base64Str) {
            try {
                var $img = $('<img class="imgSciIOutputImage"></img>');
                if (mIsBmp) {
                    $img.attr('src', 'data:image/bmp;base64,' + base64Str);
                } else {
                    var byteArray = Base64Binary.decodeArrayBuffer(base64Str);
                    var tiff = new Tiff({buffer: byteArray});
                    $img.attr('src', tiff.toDataURL());
                }
                $comp.html($img);
            } catch(err) {
                $('#divSciOperationLogs').append('<div>Failed to decode image file!</div>');
            }
        }
    }

    function clearResultsAndDisplay() {
        mResponses = [];

        $('#divSciOperationLogs').empty();
        
        $('#divSciOutputItemDetails').empty();

        $('#divSciOutputNotificationDetails').empty();

        $('#divSciOutpuException').hide();
        $('#divSciOutpuExceptionDetails').empty();

        //$('#divSciOutput').show();
        $('#divSciOutputImages').hide();
        $('#divSciOutputImageFront').empty();
        $('#divSciOutputImageBack').empty();

        $('#txtResponses').val('');
    } 
    
    function resetUI(all)
    {
        var xml, lines;

        $('.opTestTarget').removeProp('disabled');
        if(all) {
            $('input[name="SciOpTestTarget"]').prop('checked', false);
        }

        $('#divSciScannerInfo').hide();

        $('.btnSciAction').prop('disabled', 'disabled');
        if(!all) {
            $('#btnSciActionClaimDevice').removeProp('disabled');
        }

        $('input[name="SciOpType"]').prop('checked', false);
        $('input[name="SciOpType"]').prop('disabled', 'disabled');
        $('#divOpTypeScanOptions').hide();
        $('#divOpRequestXML').hide();

        $('.opSciBusyActions').prop('disabled', 'disabled');

        if( $('#checkboxOpDisplayRawResponse').is(':checked') ) {
            $('#divSciResponses').show();
        } else {
            $('#divSciResponses').hide();
        }

        $('#txtResponses').val('');        

        xml = $('#txtRequestXML').val();
        lines = xml.split('\n');
        $('#txtRequestXML').prop('rows', lines.length.toString());

        clearResultsAndDisplay();
    }   
    
    //Weaving UI controls
    
    $('input:radio[name="SciOpTestTarget"]').change( function() {
        $('#btnSciActionClaimDevice').removeProp('disabled');
        if($(this).val() === 'INDP' ) {
            $('#spanTestTargetEC96SN').show();
        } else {
            $('#spanTestTargetEC96SN').hide();
        }
    });
    
    function replaceOperationXMLParameter(xml) {
        var rtn = xml; 
        if ( $("#checkboxOpOptionsFrank").is(':checked') ) {
            rtn = rtn.replace("##FRANK-ENABLED##", "true");
        } else {
            rtn = rtn.replace("##FRANK-ENABLED##", "false");
        }

        if ( $("#checkboxOpOptionsEndorse").is(':checked') ) {
            rtn = rtn.replace("##ENDORSE-ENABLED##", "true");
        } else {
            rtn = rtn.replace("##ENDORSE-ENABLED##", "false");
        }
        return rtn;
    }

    function refreshOperationXMLCandidate() {
        var TEMPLATES = [
            '#templateRequestXMLScanCheck', 
            '#templateRequestXMLScanCheckWithDecision', 
            '#templateRequestXMLScanCheck', 
            '#templateRequestXMLScanIDCard', 
            '#templateRequestXMLReadMSR', 
            '#templateRequestXMLPrint'
            ], xml;

        xml = $(TEMPLATES[parseInt($('input:radio[name="SciOpType"]:checked').val()) - 1]).html().trim();

        xml = replaceOperationXMLParameter(xml);

        $('#txtRequestXML').val(xml);
        $('#txtRequestXML').prop('rows', xml.split('\n').length.toString());
    }

    $("input.checkboxOpOptions:checkbox").change( function() {
        refreshOperationXMLCandidate();
    });

    $('input:radio[name="SciOpType"]').change( function() {
        refreshOperationXMLCandidate();

        if($(this).hasClass('opSciOperationTypesWithOptions')) {
            $('#divOpTypeScanOptions').show();
        } else {
            $('#divOpTypeScanOptions').hide();
        }

        $('#divOpRequestXML').show();
    });    
    
    $('#btnViewRequestXml').click( function() {
        $('#txtRequestXML').toggle();
        if( $('#txtRequestXML').is(':visible') ) {
            $('#btnViewRequestXml').val('Hide Operation XML <<');
        } else {
            $('#btnViewRequestXml').val('Show Operation XML >>');
        }
    });
    
    $('#checkboxOpSaveResponse').change( function(){
        if( $(this).is(':checked') ) {
            $('#textOpResponseURL').removeProp('disabled');
        } else {
            $('#textOpResponseURL').prop('disabled', 'disabled');
        }
    });
    
    //SCI operations
    
    $('#btnSciActionClaimDevice').click( function() {
        var testTarget = $( 'input:radio[name="SciOpTestTarget"]:checked' ).val();
        var scannerAddress, scannerType;
        if( testTarget === 'INDP' ) {
            scannerAddress = $('#inputTestTargetEC96SN').val();
            if( scannerAddress.length === 0 ) {
                alert('Please input the serial number for EC9600.');
                return;
            }
            scannerType = 0;
            scannerAddress = 'https://rd' + scannerAddress;
        } else if( testTarget === 'INDP:USB' ) {
            scannerType = 0;
            scannerAddress = 'https://rdm-usb-ns';
        } else if( testTarget === 'TP2' ) {
            scannerType = 1;
            scannerAddress = 'https://localhost:736';
        } else if( testTarget === 'SIMPL' ) {
            scannerType = 2;
            scannerAddress = 'https://localhost:736';
        }
        sampleConnectAndClaim(scannerType, scannerAddress);
    });

    $('#btnSciActionStartOperation').click( function() {
        var $sciOpType, startType, operationXML;
        $sciOpType = $( 'input:radio[name="SciOpType"]:checked' );
        if( $sciOpType.length === 0 ) {
            alert('Please select operation type!');
            return;
        }
        startType = $sciOpType.val();

        if( $('#checkboxOpSaveResponse').is(':checked') && $('#textOpResponseURL').val().length == 0 ) {
            alert('"Send response to a testing server" is selected.Please input testing server address!');
            return;
        }

        operationXML = $('#txtRequestXML').val();

        $('.opSciIdleActions').prop('disabled', 'disabled');
        if( startType == '3' ) {
            $('.opSciBusyActions').removeProp('disabled');
        }

        $('.opRuningParameters').prop('disabled', 'disabled');
        
        clearResultsAndDisplay();

        sampleStartOpertion(startType, operationXML);
    });

    $('#btnSciActionReleaseDevice').click( function() {
        sampleReleaseDevice();
    });
    
    $('#btnSciActionStopOperation').click( function() {
        $('#btnSciActionStopOperation').prop('disabled', 'disabled');
        sampleStopOperation();
    });
    
    $('#btnClearResults').click( function() {
        clearResultsAndDisplay();
    });

    $('#checkboxOpDisplayRawResponse').change(function () {
        if(this.checked) {
            $('#divSciResponses').show();
        } else {
            $('#divSciResponses').hide();
        }
    });

    $(window).on('load', function(){
        function clientOS() {
            var userAgent = window.navigator.userAgent,
                platform = window.navigator.platform,
                macosPlatforms = ['Macintosh', 'MacIntel', 'MacPPC', 'Mac68K'],
                windowsPlatforms = ['Win32', 'Win64', 'Windows', 'WinCE'],
                iosPlatforms = ['iPhone', 'iPad', 'iPod'],
                os = null;
          
            if (macosPlatforms.indexOf(platform) !== -1) {
              os = 'Mac OS';
            } else if (iosPlatforms.indexOf(platform) !== -1) {
              os = 'iOS';
            } else if (windowsPlatforms.indexOf(platform) !== -1) {
              os = 'Windows';
            } else if (/Android/.test(userAgent)) {
              os = 'Android';
            } else if (!os && /Linux/.test(platform)) {
              os = 'Linux';
            }
          
            return os;
        }

        function dispalyForMSIE() {
            var ua = window.navigator.userAgent;
            var msie = ua.indexOf("MSIE ");
        
            if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv:11\./))  // If Internet Explorer, return version number
            {
                $('#divSampleWebHelp').show();
                $('#divSampleWebHelpIE').show();
                if(window.location.hostname) {
                    $('#spanIEHostname').text('"' + window.location.protocol + '://' + window.location.hostname + '"');
                }
            }
        }

        if(clientOS() === 'Windows') {
            if(window.location.protocol.toUpperCase() === 'HTTPS:')
            {
                dispalyForMSIE();
            }
            $('#divScannerTypePeripheral').show();
        } else {
            $('#divScannerTypePeripheral').hide();
        }
        
        resetUI(true);
    });

    $(window).on('beforeunload', function() {
        if (mSciHelper) {
            mSciHelper.release(USER_ID);
        }
    });
});