/*global*/
var RDMSciV1 = {
    deferred: function(owner) {
        var mFailCallbacks = [], mCompleteCallbacks = [], mValues, mReason;

        this.resolve = function() {
            if (mValues || mReason)
                return false;
            mValues = Array.prototype.slice.call(arguments);
            mValues.unshift(owner);

            mCompleteCallbacks.forEach(function(c){
                c.apply(null, mValues);
            });
            mFailCallbacks = []; // clear stored errcb
        };

        this.reject = function() {
            if (mValues || mReason)
                return false;
            mReason = Array.prototype.slice.call(arguments);
            mReason.unshift(owner);

            mFailCallbacks.forEach(function(c){
                c.apply(null, mReason);
            });
            mCompleteCallbacks = []; // clear stored donecb
        };

        this.onError = function(cb) {
            if (mValues)
                return; // nothing to do

            if (mReason) {
                setTimeout( function(){
                    cb.apply(null, mReason);
                }, 0);
            } else {
                mFailCallbacks.push(cb);
            }
            return this;
        };

        this.onComplete = function(cb) {
            if (mReason)
                return; // nothing to do

            if (mValues) {
                setTimeout( function(){
                    cb.apply(null, mValues);
                }, 0);
            } else {
                mCompleteCallbacks.push(cb);
            }
            return this;
        };

        this.abort = function() {
            if (typeof this.doAbort === "function") {
                this.onAbort();
            }
        };

        this.onAbort = null;
    },


    SciAsync: function (xSciUrl) {

        if (typeof this !== 'object')
            throw new TypeError('SciCore must be constructed via new');
        'use strict';

        var mUserId = null, mSciUrl = xSciUrl, _self = this, RESP_TYPE= { NA:0, STATE: 1, OPERATION:2, RESPXML:3, XML:4};

        function trimString(x) {
            return x.replace(/^\s+|\s+$/gm,'');
        }

        function getISODateString() {
            function pad (num) {
                var norm = Math.floor(Math.abs(num));
                return (norm < 10 ? '0' : '') + norm;
            }

            var now = new Date();
            var tzo = -(now.getTimezoneOffset());
            var dif = tzo >= 0 ? '+' : '-';

            return now.getFullYear() +
                '-' + pad(now.getMonth() + 1) +
                '-' + pad(now.getDate()) +
                'T' + pad(now.getHours()) +
                ':' + pad(now.getMinutes()) +
                ':' + pad(now.getSeconds()) +
                dif + pad(tzo / 60) +
                ':' + pad(tzo % 60);
        }

        function postSciRequest(respType, func, param, xml) {
            var request, sciXHR, xml2, rtn;

            if( !mSciUrl ) {
                throw new Error('No Scanner is connected, please call testConnection() first!');
            } else if (undefined === mUserId || mUserId === null) {
                throw new Error('claimScanner has to be invoked first!');
            }
            
            request = "Function=" + func + "&UserId=" + encodeURIComponent(mUserId);

            if (param !== undefined) {
                request = request + "&Parameter=" + param;
            }
            if (xml !== undefined) {
                xml2 = xml.replace(/[\n\r]+/g, '');
                request = request + "&Data=" + encodeURIComponent(xml2);
            }
            if (func === 'ClaimScanner') {
                request = request + "&SessionTime=" + getISODateString();
            }

            rtn = new RDMSciV1.deferred(_self);
            
            sciXHR = new XMLHttpRequest();
            sciXHR.open("POST", mSciUrl, true);
            sciXHR.setRequestHeader("Content-type",
                    "application/x-www-form-urlencoded");
            
            sciXHR.onerror = function() {
                rtn.reject("Function '" + func + "' failed. (XMLHttpRequest error)");
            };
            
            sciXHR.onreadystatechange = function() {
                var resp;
                if (sciXHR.readyState == 4) {
                    rtn.onAbort = null;
                    if( rtn.timer ) {
                        clearTimeout(rtn.timer);
                        rtn.timer = null;
                    }
                    if (sciXHR.status === 200) {
                        resp = trimString(sciXHR.responseText);
                        if( respType === RESP_TYPE.STATE ) {
                            if( resp.toUpperCase() === "IDLE" || resp.toUpperCase() === "BUSY" || resp.toUpperCase() === "ERROR" ) {
                                rtn.resolve(resp);
                            } else {
                                rtn.reject("Function 'GetState' failed. (SCI error: Unknown SCI state '" + resp + "')");
                            }
                        } else if( respType === RESP_TYPE.RESPXML ) {
                            if (resp.substr(0, 5) === "<?xml") {
                                rtn.resolve(resp);
                            } else if (resp.length == 0 || resp.toUpperCase() === "NO DATA") {
                                rtn.resolve("");
                            } else {
                                rtn.reject("Function '" + func + "' failed.(SCI error: " + resp + ")");
                            }
                        } else if( respType === RESP_TYPE.XML ) {
                            if (resp.substr(0, 5) === "<?xml") {
                                rtn.resolve(resp);
                            } else {
                                rtn.reject("Function '" + func + "' failed.(SCI error: " + resp + ")");
                            }
                        } else if( respType === RESP_TYPE.OPERATION ) {
                            if( resp !== "Success" ) {
                                rtn.reject("Function '" + func + "' failed.(SCI error: " + resp + ")");
                            } else {
                                rtn.resolve(resp);
                            }
                        } else {
                            rtn.resolve(resp);
                        }
                    } else {
                        rtn.reject("Function '" + func + "' failed. (HTTP: " + sciXHR.status + ")");
                    }
                }
            };

            rtn.onAbort = function() {
                sciXHR.abort();
                rtn.reject("Function '" + func + "' timed out.");
            };
            
            sciXHR.send(request);
            rtn.timer = setTimeout(function(){
                sciXHR.abort();
            }, 15000);
            
            
            return rtn;
        }
        
        
        function postSciOperationRequest(func, param, xml) {
            return postSciRequest(RESP_TYPE.OPERATION, func, param, xml);
        }

        // Public interfaces
        
        this.claimScanner = function(userId, scannerType) {
            var rtn;
            mUserId = userId;
            try {
                rtn = new RDMSciV1.deferred(_self);
                rtn.deferred = postSciRequest(RESP_TYPE.OPERATION, "ClaimScanner").onComplete(function(sciCore, resp) {
                    rtn.resolve(resp);
                }).onError(function(sciCore, errMsg){
                    rtn.reject(errMsg);
                    mUserId = undefined;
                });
                return rtn;
            } catch (e) {
                mUserId = undefined;
                throw e;
            }
        };


        this.releaseScanner = function(userId) {
            var rtn;
            
            if( mSciUrl === null )
                return null;

            if (userId !== undefined) {
                mUserId = userId;
            }

            try {
                rtn = new RDMSciV1.deferred(_self);
                rtn.deferred = postSciRequest(RESP_TYPE.OPERATION, "ReleaseScanner").onComplete(function(sciCore, resp) {
                    rtn.resolve(resp);
                    mUserId = undefined;
                }).onError(function(sciCore, errMsg){
                    rtn.reject(errMsg);
                    mUserId = undefined;
                });
                return rtn;
            } catch (e) {
                mUserId = undefined;
                throw e;
            }
        };


        this.getSciVersion = function() {
            return postSciRequest(RESP_TYPE.NA, "GetSciVersion");
        };
        

        this.getState = function() {
            return postSciRequest(RESP_TYPE.STATE, "GetState");
        };
        
        this.startOperation = function(startType, xml) {
            if (startType === undefined) {
                throw new Error("Parameter 'startType' is missing in startOperation");
            }
            if (xml === undefined) {
                throw new Error("Parameter 'xml' is missing in startOperation");
            }
            
            return postSciOperationRequest("StartOperation", startType, xml);
        };
        
        
        this.completeOperation = function(completeType, xml) {
            if (completeType === undefined) {
                throw new Error("Parameter 'completeType' is missing in CompleteOperation");
            }
            if (completeType == 1 && xml === undefined) {
                throw new Error("Parameter 'xml' is missing in CompleteOperation");
            }

            return postSciOperationRequest("CompleteOperation", completeType, xml);
        };

        
        this.getOperationXml = function() {
            return postSciOperationRequest("GetOperationXml");
        };

        
        this.getResponseXml = function(wait) {
            return postSciRequest(RESP_TYPE.RESPXML, "GetResponseXml", wait);
        };
        

        this.getScannerXml = function() {
            return postSciRequest(RESP_TYPE.XML, "GetScannerXml");
        };
    },


    connectToDevice: function(deviceTarget) {
        var deferred = new RDMSciV1.deferred(null)
            , candidateHosts = []
            , testPath = "/SCI/7.0/sci.esp"
            , allDoneFlags = [];

        function doTestConnection(xhost, xtestPath, xonTestPassed, xonTestFailed) {
            var sciXHR = new XMLHttpRequest();

            sciXHR.onerror = function() {
                if (typeof xonTestFailed === 'function')
                    xonTestFailed.call(null);
            };

            sciXHR.onreadystatechange = function() {
                if (this.readyState === 4) {
                    if (this.status === 200) {
                        if (typeof xonTestPassed === 'function') {
                            xonTestPassed.call(null, xhost + xtestPath);
                        }
                    } else {
                        if (typeof xonTestFailed === 'function') {
                            xonTestFailed.call(null);
                        }
                    }
                }
            };

            try {
                sciXHR.open("POST", xhost + xtestPath, true);
                sciXHR.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                sciXHR.send("Function=GetSciVersion&UserId=Any&Parameter=&Data=");
            } catch(err) {
                if (typeof xonTestFailed === 'function') {
                    xonTestFailed.call(null, err);
                }
            }
        }
        
        if (typeof deviceTarget !== 'string') {
            if (deviceTarget !== undefined && deviceTarget !== null) {
                throw new TypeError('connectToDevice() requires a string parameter ');
            }
        }

        if (!deviceTarget || deviceTarget.toUpperCase() === "HTTPS://RDM-USB-NS" || deviceTarget.toUpperCase() === "RDM-USB-NS") {
            candidateHosts = ["https://rdm-usb-ns", "https://rdm-usb-ns.local", "https://usb.rdmscanners.net"];
        } else if (deviceTarget.toUpperCase() === "HTTPS://LOCALHOST:736" || deviceTarget.toUpperCase() === "LOCALHOST" ) {
            candidateHosts = [ "https://localhost:736" ];
        } else if (/^HTTPS:\/\/RD[0-9]{13}$/.test(deviceTarget.toUpperCase())) {
            candidateHosts = [ deviceTarget, deviceTarget + ".local" ];
        } else if (/^RD[0-9]{13}$/.test(deviceTarget.toUpperCase())) {
            candidateHosts = [ "https://" + deviceTarget, "https://" + deviceTarget + ".local" ];
        } else if (/^[0-9]{13}$/.test(deviceTarget)) {
            candidateHosts = [ "https://rd" + deviceTarget, "https://rd" + deviceTarget + ".local" ];
        } else if (deviceTarget.toUpperCase().startsWith("HTTPS://")) {
            candidateHosts = [ deviceTarget ];
        } else {
            candidateHosts = [ "https://" + deviceTarget ];
        }

        allDoneFlags = new Array(candidateHosts.length);
        allDoneFlags.forEach(function(_, xi) {
            this[xi] = false;
        });

        candidateHosts.forEach(function(xhost, xi) {
            doTestConnection(
                xhost,
                testPath,
                function(xUrl) {
                    deferred.resolve(new RDMSciV1.SciAsync(xUrl));
                },
                function() {
                    var xj;
                    allDoneFlags[xi] = true;
                    for (xj = 0; xj < allDoneFlags.length; ++xj) {
                        if(!allDoneFlags[xj]) {
                            return;
                        }
                    }
                    deferred.reject("Unable to connect to the device!");
                });
        });

        return deferred;
    }

};
