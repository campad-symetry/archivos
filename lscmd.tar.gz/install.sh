#!/bin/sh

INC_INSTALL_DIR=/usr/local/include
LIB_INSTALL_DIR=/usr/local/lib
EXE_INSTALL_DIR=/usr/local/bin
ETC_INSTALL_DIR=/usr/local/etc

#****************************************************************
# LIB
#****************************************************************

NAME=libCtsDecod.so
VERSION=.9.3.0.0
FULLNAME=$NAME$VERSION
CTSDECOD_DIR=/CtsDecod
CTSDECOD_FONT_DIR=$CTSDECOD_DIR/font

echo "Installing $FULLNAME shared library"

echo $LIB_INSTALL_DIR/$FULLNAME
cp -i $FULLNAME $LIB_INSTALL_DIR/$FULLNAME

echo $LIB_INSTALL_DIR/$NAME
ln -s $LIB_INSTALL_DIR/$FULLNAME $LIB_INSTALL_DIR/$NAME

echo "Install font files for decode"
mkdir $ETC_INSTALL_DIR/$CTSDECOD_DIR
mkdir $ETC_INSTALL_DIR/$CTSDECOD_FONT_DIR
cp -i fontPackage/*.* $ETC_INSTALL_DIR/$CTSDECOD_FONT_DIR

#****************************************************************

NAME=libBarDecode.so
VERSION=.2.4.0.0
FULLNAME=$NAME$VERSION

echo "Installing $FULLNAME shared library"

echo $LIB_INSTALL_DIR/$FULLNAME
cp -i $FULLNAME $LIB_INSTALL_DIR/$FULLNAME

echo $LIB_INSTALL_DIR/$NAME
ln -s $LIB_INSTALL_DIR/$FULLNAME $LIB_INSTALL_DIR/$NAME

#****************************************************************

NAME=libMICRDecode.so
VERSION=.1.5.2.0
FULLNAME=$NAME$VERSION

echo "Installing $FULLNAME shared library"

echo $LIB_INSTALL_DIR/$FULLNAME
cp -i $FULLNAME $LIB_INSTALL_DIR/$FULLNAME

echo $LIB_INSTALL_DIR/$NAME
ln -s $LIB_INSTALL_DIR/$FULLNAME $LIB_INSTALL_DIR/$NAME

#****************************************************************

NAME=liblsapi.so
VERSION=
FULLNAME=$NAME$VERSION

echo "Installing $FULLNAME shared library"

echo $LIB_INSTALL_DIR/$FULLNAME
cp -i $FULLNAME $LIB_INSTALL_DIR/$FULLNAME

#echo $LIB_INSTALL_DIR/$NAME
#ln -s $LIB_INSTALL_DIR/$FULLNAME $LIB_INSTALL_DIR/$NAME

#****************************************************************
# EXE
#****************************************************************

NAME=lscmd
echo "Installing $NAME executable"
echo $EXE_INSTALL_DIR/$NAME
cp -i $NAME $EXE_INSTALL_DIR/$NAME

#****************************************************************

echo "Done"
