rm *.jpg
rm *.tif
echo 'LS100 test script'
read -p 'Scan with jpg format'
lscmd 1 1 5 1
read -p 'Scan with jpg format'
lscmd 1 1 5 2
read -p 'Read badge track 1'
lscmd 1 2 2
read -p 'Read badge track 2'
lscmd 1 2 4
