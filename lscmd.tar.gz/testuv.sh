rm *.jpg
rm *.tif
echo 'LS40xuv test script'
read -p 'Scan with jpg format'
lscmd 2 1 41 1
read -p 'Scan with jpg format'
lscmd 2 1 41 2
read -p 'Read badge track 1'
lscmd 2 2 2
read -p 'Read badge track 2'
lscmd 2 2 4
