rm *.jpg
rm *.tif
echo 'LS40x test script'
read -p 'Scan with jpg format'
lscmd 2 1 5 1
read -p 'Scan with jpg format'
lscmd 2 1 5 2
read -p 'Read badge track 1'
lscmd 2 2 2
read -p 'Read badge track 2'
lscmd 2 2 4
