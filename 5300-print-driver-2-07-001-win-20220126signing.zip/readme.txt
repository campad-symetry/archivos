********************************************************************************
* Pertech Industries Inc.
* 5300 Series Printer
* Microsoft (R) Windows 10 Printer Driver
* Version 2.07.000.00
* November 10, 2020
********************************************************************************
********************************************************************************
********************************************************************************
* Installation
********************************************************************************
1. Unzip the 5300 driver package to a temporary folder.  Make a note of where
this folder is located for later.

2. If using USB,  connect the USB cable between the 5300 printer and computer.
Then turn on the 5300.  This causes Windows to assign the 5300 to a Virtual USB
Printer Port, which will need to be selected in the "Select Printer Port" step
described below.

3. Use the "Add Printer Wizard" to install this driver.   
Find "Printers And Faxes" on the "Start" menu.   (Some machines
may have this section under the sub-heading "Control Panel"). Click on "Add
Printer" and click "Next".

4. Select "Local Printer" and uncheck "Automatically detect and install my Plug
and Play printer". Click "Next".  Note that unchecking "Automatically detect..."
is optional, but speeds up the installation process.

5. To "Select a Printer Port", pull down the drop box.  If using USB, select the
virtual USB port number for the printer.  (note that finding
this if there is more than one shown may require some trial and error.  It
recommended to start with the port with the highest number, i.e. if USB001 and
USB002 are shown, select USB002.  You can always change this later.  See trouble-
shooting section of this document for more details.)  If using RS-232 serial,
select the appropriate COM port that the printer is attached and note that later
you may need to adjust RS-232 settings.   Click "Next".

6. The "Install Printer Software" section will display a list of printers that
Windows currently supports and show a button called "Have Disk".  Click "Have Disk"
and browse to the temporary folder where the driver was unzipped in step 1.
In this folder, Windows will find "5300.INF".  Click "Open", then click "OK".
Click "OK" again.

7. Four different versions of the 5300 will be listed:
        5371 (impact receipt and validation)
        5374 (impact validation only)
	5351 (inkjet receipt and validation)
	5354 (inkjet validation only).
Click on the appropriate model and click "Next".

8. You can optionally rename your printer and assign it as default.  Click "Next".
Note that "Set as Default" is optimal, as it allows some WYSIWYG applications like
word processors to be to use resident printer fonts.

9. Click whether or not you want the printer to be shared with other PC's on a
network.  Click "Next".

10. Click whether or not to print a test page and click "Next".  (Note that if
you are not yet sure of the RS-232 parameters if using serial or which USB port
(if the "Add Wizard" showed more than one is step 5), that selecting "No" is the
best choice for now.

11. Click "Finish".  Windows will issue a warning that the driver is not
digitally signed by Microsoft.  To install the driver, click "Continue."
********************************************************************************
* Printer Setup
********************************************************************************
The 5300 series of printers must be setup to use ACL Language for this driver to
work.  To check this, power up the printer while holding down on the paper feed
switch and wait for the printer to print its configuration settings.  Under the
heading "Printer Control Language", it should say "PCL:   ACL Language".  If it
does not, you may change this setting using the Pertech Resources 5300
Configuration Setup Utility, or use the One-Button setup feature.  (To enter one
button setup feature, press the feed button within 5 seconds after the
configuration settings are printed and the message "Press paper feed to change
configuration" is printed."  Then follow the instructions printed on the paper.)

********************************************************************************
* COMx Port Set up
********************************************************************************
If using RS-232, it is likely that first time installers will need to adjust the
RS-232 parameters to match the attached printer. After installing the driver, go
to "Printers and Faxes" on the "Start" menu and right click on the 53xx printer
driver.  Select "Properties".  Select the "Ports" tab.  Select "Configure Port".
Verify that the baud rate, parity data and stop bits match the configured
parameters of the attached printer.  (To see the printer settings, power up the
5300 printer with feed button pushed and paper installed.)

VERY IMPORTANT:  Make sure that the Windows COM port is set for Flow Control =
Hardware (or XON/XOFF if the attached printer is configured to for XON/XOFF).  If
Flow Control is set to "None", garbage print may eventually result.

********************************************************************************
* Bi-directional Status
********************************************************************************
The printer driver will display printer status via an icon in the Windows System
Tray, which is located on the task bar next to the clock.  There are several
different icons that could be possibly displayed, but the one shown represents
the last printer status item that changed.  To display the complete status,
right click on the icon and a window will pop-up showing all status items.

The icon can be turned off in a number of ways.  Clicking on the 53xx Printer
Property menu will shut the icon off until the next print job is sent.  It can
also be optionally disabled by unchecking "Enable bidirectional support" in the
"Ports" tab , or unchecking "Enable Status" in the "Device Setting" tab of
the 53xx Printer Properties dialog box.

To see a complete list of icons, please click "Help" on the "Device Setting" tab
of the 53xx Printer Property page.

Limited status information is also displayed in the "Details" view of the
"Printers and Faxes"dialog box under the "Status" column.

********************************************************************************
* Printer Configuration
********************************************************************************
The printer may be configured at any time by clicking on the printer icon in the
printer folder with the right mouse button and selecting Properties.  The
Device Setting Tab allows the user to set the following parameters.

Validation Height
-----------------------
This is set to maximum (1.75 inches) as a default but can be set between 1.00 to
1.75 inches.  This should be set to match the printer configuration setting
under the heading "Document Stop".

Bill out length
------------------
This is set to 1.57 inches (40 mm) as a default but can be changed as required.
�Bill out� refers to the length of paper that is appended to the end of a print
job and is normally used to move the paper up to the printer�s tear bar.  It is
only operational if selected in the Document Defaults dialog box.

Clamp Delay
----------------
This is set to 1 second as a default and refers to the delay between the
printer sensing that a validation slip has been inserted into the validation slot
and the validation clamp operating.  It is recommended that this be no less than
1 second.

About
--------
Clicking this button gives version information about the driver.

Enable Status
-----------------
If this box is checked (this is the default condition) then information about
the current status of the printer is displayed in the bottom of the screen on
the task bar.

Ink Level (Inkjet models only)
----------------------------------------
This bar is adjusted when sending a print job and gives a visual representation
of the amount of ink left in the cartridge.

Clean Nozzles (inkjet models only)
---------------------------------------------
The 535x printers perform automatic maintenance for best print quality when
required, but if it is desired to force the printer to self clean its nozzles,
click this button.

********************************************************************************
* Printing Preferences
********************************************************************************
If the printer icon in the printers folder is clicked with the right mouse
button and Printing Preferences selected the various parameters to do with the
document may be modified.  This dialog box is also usually available from within
an application within its printer setup.  Note that the current application's
Printing Preferences will override any set by other applications.

Print Mode
---------------
This defaults to journal and refers to how the job should be printed.  There are
three main choices:

	Journal Mode.  This is a standard mode of Windows operation and simply
	means that the job will be printed on the journal roll with a fixed page
	length - set in the Paper length box.  (Applications can select Journal
	mode when dmPaperSize = 257)

	Continuous Mode.  This is a special mode of operation which permits the
	journal roll to be used but without a fixed page length.  In practice
	there is a maximum of approximately 24 inches (600mm) after which the
        driver will insert top 	and bottom margins before continuing.  To minimize
	this effect top and bottom margins should be set to zero in continuous
	mode.  Headers and Footers in this mode will also give unpredictable
	results and should therefore be avoided. (Applications can select Continuous
	mode when dmPaperSize = 258)

	Validation Mode.  Selection of this mode will cause the print job to be
	printed on a Validation slip, which must be manually inserted into the
	slot in the printer. (Applications can select Validation
	mode when dmPaperSize = 259)

	Wide Validation Mode.  Selection of this mode will again cause the print job
	to be printed on a Validation slip, which must be manually inserted into the
	slot in the printer. This mode is available only in Inkjet printers.  Please
	verify that the printer is configured in the correct mode for this paper type.
	(Applications can select Validation mode when dmPaperSize = 260)

	The 5300 inkjet printers perform periodic head maintenance for optimal
	print quality.  In the case of validation printing, it is possible to get
	ink spray on the form if head maintenance is in progress.  To prevent this,
	always wait until the "Form" LED on the front of the printer is blinking
	before inserting the form.

Upside Down
------------------
If this box is checked then all jobs will be sent to the printer last line first
and upside down.  This mode is more usually employed when printing on certain
validation jobs.  It is not available if continuous mode is selected.

Bill Out Mode
------------------
This specifies if the Bill Out setting in the Printer Configuration should be
used at the end of a document, the end of a page or not at all.  The default
setting is the end of a document.  In most applications the bottom margin setting
is used unless it is set to zero, in which case the bill out distance is used.

Horizontal Resolution
-----------------------------
This can be set to 160 Dots Per Inch or 80 Dots Per Inch.  160 DPI will yield
 better printer quality but use more ink than 80 DPI.  Graphics and True Type
fonts will also print slower at 160 DPI.  The printer's resident fonts (when
used) will also change quality between 80 DPI.  (Applications, such as Visual
Basic, can use the PrintQuality attribute to select.  i.e. vbPRPQHigh and
vbPRPQMedium select 160 Dpi mode and vbPRPQLow and vbPRPQDraft select 80 Dpi).

About
---------
Clicking this button gives version information about the driver.

********************************************************************************
*  Use of The Driver from within Applications
********************************************************************************

Margins:
-----------
Most word processor packages tend to automatically set all margins to
approximately 1 inch (25 mm).  With a printer whose field width is less than 3
inches (3.4 inches with Wide Validation) this will obviously need to be changed.
A good starting point is to set all margins to zero.  This will usually ensure that
the left and right margins are set to the minimum (You may need to specify the Fix
utility in Word to do this).  It is recommended that the top and bottom margins are
also set to zero. Note that there is an inherent top margin associated with the 53xx
series printers which corresponds to the distance between the print head and the tear
bar in Journal and Continuous modes.  Bottom margins should use the Bill Out feature
of the driver.

Resident Printer Fonts:
------------------------------
Any of the fonts available to applications can be used by the printer (See below
about the Control Font).  It should be noted however that resident printer fonts
(signified by a small printer icon in the font list) print much faster and with
slightly better resolution than True Type fonts (signified by the small TT icon).
The style of printer fonts as compared with the enormous range of available True
Type fonts is tiny.  The choice of when to use each type will depend very
largely on the application.

Note that while it is possible to print TT fonts and/or Graphics
with generic printer fonts on the same line this is a worst of both worlds
situation and should if possible be avoided.  (WYSIWYG applications may appear
with unexpected gaps in print. see troubleshooting section for details.)

Note that there are two point sizes for each font: 9 and 18.  Most applications
require that these be specifically set to either 9 or 18.  If not, then the
application will either select a true type font instead, or the results on
the screen will not match those on the printed page. These resident fonts are:
	Wide 8 CPI
	Wide 10 CPI
	Normal 10 CPI
	Normal 11.4 CPI
	Normal 13.3 CPI
	Normal 16 CPI
	Normal 20 CPI
Bold, Italic and Underline versions are all available.  Inverse printing causes
these fonts to be printed all black.

There is also an OCR-A Inkjet font available.  This font is available in 9 point
size only, without a Bold, Italic or Underline version.  When using an Impact
printer, the printer will substitute another font, as this font is not available.

The 5300 printer driver does export built in underlined versions of the printer
fonts.  However, many software applications (such as word processors) will either
use a graphics line to simulate the underline, or not produce an underline at all.
In the cases where underlining is desired but not available through the software
application, the control font character �U� will toggle on/off underlining for
printer fonts.

Note that some word processors will not select printer fonts if the 53xx printer
is not set as the default printer.  See troubleshooting for more information.

Control Font:
-----------------
The Control Font is the means by which the printer�s extra features can be controlled.
On a standard printer there is no such thing as a Cash Drawer controller so the
Windows operating system was designed without a means of such control.
The way around this problem is to use the Control Font that appears in the list
as a generic printer font.  These are the only characters that are used:

	A - Fire cash drawer A
	B - Fire cash drawer B
	C - Clean Nozzles on printhead
	U - Toggle underlining on/off for resident printer fonts.
	1 - Select pre stored logo 1
	2 - Select pre stored logo 2
	3 - Select pre stored logo 3
	4 - Select pre stored logo 4
	5 - Select pre stored logo 5
	6 - Select pre stored logo 6
	7 - Select pre stored logo 7
	8 - Select pre stored logo 8
	9 - Select pre stored logo 9


Note that only the capital letters in this font do anything and while the
characters appear on the screen the printer will not print them on the job,
although they may slightly affect the page length.  These characters should
appear on a line by themselves, rather than embedded into other text.

If there was no logo downloaded to the printer that corresponds to the digit,
the printer will ignore the Control font digit and nothing will be printed.

Note that the driver does not have the ability to store logos, only print them.


Status:
---------
The status information is not exported by the driver and is only used to
generate the status display on the task bar.  Note that the icon displayed
on the task bar only displays the last change in status from the printer.
To view the current complete status report, click on the status icon and a
small dialog box will appear.

********************************************************************************
* Printer Commands
********************************************************************************
This page allows raw printer commands to be sent to the printer in addition to
the Windows print job.  Since the 5300 printer driver is designed for printers
configured for the ACL command language, please refer to the �5300 Printer Series
ACL Programming Manual� for a list and description of commands that are available.

Commands can be entered in ASCII text or Hexadecimal format.  To enter in hex,
bracket the hex code with <> symbols.

If spaces are added between characters, the printer driver will automatically
convert them to <20>, or 20h, which is equivalent to ASCII space character, when
OK or Apply is clicked.

Note that some commands will affect page length and may make the WYSIWYG
(What You See Is What You Get) system no longer an accurate representation of
the printed page.

Start of Document
------------------------
This command will be sent at the start of each print job, after the printer
driver transmits its own print job setup commands to the printer.

Start of Page
-----------------
This command will be sent at the start of each page break in a document.

End of Page
----------------
This command will be sent at the end of each page break in a document.

End of Document
------------------------
This command will be sent at the end of each print job.

********************************************************************************
* Troubleshooting
********************************************************************************
A.  Printer prints garbage when using RS-232 and/or printer occasionally prints
garbage even when not sending print job.
	- Solution : Verify that the COM port is set up to match the attached
	printer.  See "COMx Port Setup" above.

B.  Printer prints some expected data combined with garbage.
	- Solution : Verify that the printer is configured to use ACL language.

C.  Printer is not printing and receive error message from Windows that it failed
to print.
	- Verify that the printer is connected and powered on.
	- Cancel the document.
	- Solution for USB users:
		Windows may have assigned the 53xx printer to some other port
		than the one chosen during the install. Select a different
		"USB00x Virtual Printer Port".  To do this, go to 53xx Printer
 		Properties and select the Ports tab.

		If the printer is on and connected, but the 53xx icon displayed
		in the Printers and Faxes dialog box is grayed out, right click
		on the 53xx icon and check "Use Printer Off Line".  Try sending
		the print job again.  You may have to repeat this process if
		several "USB00x Virtual Printer Ports" are displayed under
 		the Ports tab until you find the correct port.  Always
		remember to cancel the documents that fail to print.
	- Solution for RS-232 users:
		Verify that the NULL MODEM cable is connected to the port
		selected by the printer driver.
		Verify that the baud rate, parity, data and stop bits match.
		If the printer is on and connected, but the 53xx icon displayed
		in the Printers and Faxes dialog box is grayed out,
		right click on the 53xx icon and check "Use Printer Off Line".
		Try sending the print job again.   Always remember
		to cancel the documents that fail to print.

D.  Print appears with horizontal gaps in graphics or TT fonts.
	- Solution:  This can happen with word processors or other WYSIWYG
		applications when a document contains a combination of resident
		printer fonts and graphics or TT fonts.  Most likely, a graphic
		and resident printer font exist on the same line or what would
		translate to one sweep of the printhead.  To avoid this, do not
		combine resident fonts with graphics on the same line.  (i.e.
		press 'enter' to seperate them).  Note that it is not always
		obvious, such as the case where a resident font is selected and
		the space bar is used to space over a graphic or TT font
		on a line.

E.  An application uses TT Font approximation instead of the selected resident font.
        - Solution 1:  Before opening the document that contains 53xx Resident font
		selections, verify that the 53xx printer driver is "Set As Default"
		under "Printers and Faxes".  If it is not, close the document, set
		the 53xx Printer as Default Printer, and re-open the document.
		Resend the document to the printer.
		Note that some word processors will not allow printer fonts to be
		selected.  i.e. no printer fonts appear on the font select dialog box.
        - Solution 2:  Make sure that the resident font point size is either 9
                or 18.  (or for OCR-A Inkjet, the point size is 9).

F.  An application will not underline a resident printer font even though the underline
    attribute is selected.
	- Solution:  The 5300 printer driver does export built in underlined versions of
	 	the printer fonts.  However, many software applications (such as word
		processors) will either use a graphics line to simulate the underline,
		or not produce an underline at all.  In the cases where underlining
		is desired but not available through the software application, the
		control font character �U� will toggle on/off underlining for printer fonts.

G.  An application using resident printer fonts has a screen display that does
    not match what is printed.  i.e. characters per line does not match,
    underlining strikes through characters, characters wrap to the next line
    incorrectly, etc.
        - Solution:  Check to make sure that the font is using a point size
        of 9 or 18.  These are the only point sizes supported by the driver.
        (Note OCR-A Inkjet only supports a point size of 9).

********************************************************************************
* Uninstall
********************************************************************************
1. Open up "Printers and Faxes" in Windows, highlight the 53xx printer(s) and
select "Delete".

2. To fully remove the driver from the system, in "Printers and Faxes", select
"File" on the top menu, then "Server properties".  Select the "Driver" tab,
highlight the 53xx driver and click on "Remove".  If Windows gives a message
that the driver is in use and cannot be removed, restart Windows and repeat
this step.

********************************************************************************
* Support
********************************************************************************
Pertech Industries Inc.
contact@pertechindustries.com
1-800-800-6614
